﻿namespace PDisater0030482323023
{
    partial class frmSobre
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSobre));
            this.txtBoxSobre = new System.Windows.Forms.RichTextBox();
            this.txtBoxRA3 = new System.Windows.Forms.TextBox();
            this.txtBox2 = new System.Windows.Forms.TextBox();
            this.txtBoxRA1 = new System.Windows.Forms.TextBox();
            this.txtBoxMembro1 = new System.Windows.Forms.TextBox();
            this.txtBoxAtividade = new System.Windows.Forms.TextBox();
            this.txtBoxMembro3 = new System.Windows.Forms.TextBox();
            this.txtBoxMembro2 = new System.Windows.Forms.TextBox();
            this.txtBoxVersao = new System.Windows.Forms.TextBox();
            this.txtBoxProfessora = new System.Windows.Forms.TextBox();
            this.txtBoxMateria = new System.Windows.Forms.TextBox();
            this.lblVersao = new System.Windows.Forms.Label();
            this.lblProfessora = new System.Windows.Forms.Label();
            this.lblAtividade = new System.Windows.Forms.Label();
            this.lblMateria = new System.Windows.Forms.Label();
            this.lblRA1 = new System.Windows.Forms.Label();
            this.lblRA2 = new System.Windows.Forms.Label();
            this.lblRA3 = new System.Windows.Forms.Label();
            this.lblSobre = new System.Windows.Forms.Label();
            this.lblMembro3 = new System.Windows.Forms.Label();
            this.lblMembro2 = new System.Windows.Forms.Label();
            this.lblMembro1 = new System.Windows.Forms.Label();
            this.btnFechar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtBoxSobre
            // 
            this.txtBoxSobre.Font = new System.Drawing.Font("Microsoft Tai Le", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxSobre.Location = new System.Drawing.Point(25, 280);
            this.txtBoxSobre.Name = "txtBoxSobre";
            this.txtBoxSobre.ReadOnly = true;
            this.txtBoxSobre.Size = new System.Drawing.Size(525, 57);
            this.txtBoxSobre.TabIndex = 31;
            this.txtBoxSobre.Text = resources.GetString("txtBoxSobre.Text");
            // 
            // txtBoxRA3
            // 
            this.txtBoxRA3.Location = new System.Drawing.Point(415, 208);
            this.txtBoxRA3.Name = "txtBoxRA3";
            this.txtBoxRA3.ReadOnly = true;
            this.txtBoxRA3.Size = new System.Drawing.Size(135, 22);
            this.txtBoxRA3.TabIndex = 30;
            this.txtBoxRA3.Text = "0030482323032";
            // 
            // txtBox2
            // 
            this.txtBox2.Location = new System.Drawing.Point(415, 166);
            this.txtBox2.Name = "txtBox2";
            this.txtBox2.ReadOnly = true;
            this.txtBox2.Size = new System.Drawing.Size(135, 22);
            this.txtBox2.TabIndex = 29;
            this.txtBox2.Text = "0030482413004";
            // 
            // txtBoxRA1
            // 
            this.txtBoxRA1.Location = new System.Drawing.Point(415, 124);
            this.txtBoxRA1.Name = "txtBoxRA1";
            this.txtBoxRA1.ReadOnly = true;
            this.txtBoxRA1.Size = new System.Drawing.Size(135, 22);
            this.txtBoxRA1.TabIndex = 28;
            this.txtBoxRA1.Text = "0030482323023";
            // 
            // txtBoxMembro1
            // 
            this.txtBoxMembro1.Location = new System.Drawing.Point(107, 124);
            this.txtBoxMembro1.Name = "txtBoxMembro1";
            this.txtBoxMembro1.ReadOnly = true;
            this.txtBoxMembro1.Size = new System.Drawing.Size(254, 22);
            this.txtBoxMembro1.TabIndex = 27;
            this.txtBoxMembro1.Text = "Paulo Eduardo Lopes Dorth";
            // 
            // txtBoxAtividade
            // 
            this.txtBoxAtividade.Location = new System.Drawing.Point(107, 75);
            this.txtBoxAtividade.Name = "txtBoxAtividade";
            this.txtBoxAtividade.ReadOnly = true;
            this.txtBoxAtividade.Size = new System.Drawing.Size(158, 22);
            this.txtBoxAtividade.TabIndex = 26;
            this.txtBoxAtividade.Text = "Desaster";
            // 
            // txtBoxMembro3
            // 
            this.txtBoxMembro3.Location = new System.Drawing.Point(107, 208);
            this.txtBoxMembro3.Name = "txtBoxMembro3";
            this.txtBoxMembro3.ReadOnly = true;
            this.txtBoxMembro3.Size = new System.Drawing.Size(254, 22);
            this.txtBoxMembro3.TabIndex = 25;
            this.txtBoxMembro3.Text = "Roberto Junior de Freitas Ramos";
            // 
            // txtBoxMembro2
            // 
            this.txtBoxMembro2.Location = new System.Drawing.Point(107, 166);
            this.txtBoxMembro2.Name = "txtBoxMembro2";
            this.txtBoxMembro2.ReadOnly = true;
            this.txtBoxMembro2.Size = new System.Drawing.Size(254, 22);
            this.txtBoxMembro2.TabIndex = 24;
            this.txtBoxMembro2.Text = "Matheus da Silva Santana";
            // 
            // txtBoxVersao
            // 
            this.txtBoxVersao.Location = new System.Drawing.Point(415, 75);
            this.txtBoxVersao.Name = "txtBoxVersao";
            this.txtBoxVersao.ReadOnly = true;
            this.txtBoxVersao.Size = new System.Drawing.Size(135, 22);
            this.txtBoxVersao.TabIndex = 22;
            this.txtBoxVersao.Text = "1.0";
            // 
            // txtBoxProfessora
            // 
            this.txtBoxProfessora.Location = new System.Drawing.Point(415, 27);
            this.txtBoxProfessora.Name = "txtBoxProfessora";
            this.txtBoxProfessora.ReadOnly = true;
            this.txtBoxProfessora.Size = new System.Drawing.Size(135, 22);
            this.txtBoxProfessora.TabIndex = 23;
            this.txtBoxProfessora.Text = "Denilce";
            // 
            // txtBoxMateria
            // 
            this.txtBoxMateria.Location = new System.Drawing.Point(107, 23);
            this.txtBoxMateria.Name = "txtBoxMateria";
            this.txtBoxMateria.ReadOnly = true;
            this.txtBoxMateria.Size = new System.Drawing.Size(158, 22);
            this.txtBoxMateria.TabIndex = 21;
            this.txtBoxMateria.Text = "LPII";
            // 
            // lblVersao
            // 
            this.lblVersao.AutoSize = true;
            this.lblVersao.Font = new System.Drawing.Font("Microsoft Tai Le", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVersao.Location = new System.Drawing.Point(351, 81);
            this.lblVersao.Name = "lblVersao";
            this.lblVersao.Size = new System.Drawing.Size(54, 18);
            this.lblVersao.TabIndex = 19;
            this.lblVersao.Text = "Versão";
            // 
            // lblProfessora
            // 
            this.lblProfessora.AutoSize = true;
            this.lblProfessora.Font = new System.Drawing.Font("Microsoft Tai Le", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProfessora.Location = new System.Drawing.Point(325, 30);
            this.lblProfessora.Name = "lblProfessora";
            this.lblProfessora.Size = new System.Drawing.Size(80, 18);
            this.lblProfessora.TabIndex = 18;
            this.lblProfessora.Text = "Professora";
            // 
            // lblAtividade
            // 
            this.lblAtividade.AutoSize = true;
            this.lblAtividade.Font = new System.Drawing.Font("Microsoft Tai Le", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAtividade.Location = new System.Drawing.Point(21, 81);
            this.lblAtividade.Name = "lblAtividade";
            this.lblAtividade.Size = new System.Drawing.Size(73, 18);
            this.lblAtividade.TabIndex = 20;
            this.lblAtividade.Text = "Atividade";
            // 
            // lblMateria
            // 
            this.lblMateria.AutoSize = true;
            this.lblMateria.Font = new System.Drawing.Font("Microsoft Tai Le", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMateria.Location = new System.Drawing.Point(33, 30);
            this.lblMateria.Name = "lblMateria";
            this.lblMateria.Size = new System.Drawing.Size(60, 18);
            this.lblMateria.TabIndex = 17;
            this.lblMateria.Text = "Materia";
            // 
            // lblRA1
            // 
            this.lblRA1.AutoSize = true;
            this.lblRA1.Font = new System.Drawing.Font("Microsoft Tai Le", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRA1.Location = new System.Drawing.Point(367, 127);
            this.lblRA1.Name = "lblRA1";
            this.lblRA1.Size = new System.Drawing.Size(39, 18);
            this.lblRA1.TabIndex = 15;
            this.lblRA1.Text = "RA 1";
            // 
            // lblRA2
            // 
            this.lblRA2.AutoSize = true;
            this.lblRA2.Font = new System.Drawing.Font("Microsoft Tai Le", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRA2.Location = new System.Drawing.Point(367, 173);
            this.lblRA2.Name = "lblRA2";
            this.lblRA2.Size = new System.Drawing.Size(39, 18);
            this.lblRA2.TabIndex = 14;
            this.lblRA2.Text = "RA 2";
            // 
            // lblRA3
            // 
            this.lblRA3.AutoSize = true;
            this.lblRA3.Font = new System.Drawing.Font("Microsoft Tai Le", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRA3.Location = new System.Drawing.Point(367, 215);
            this.lblRA3.Name = "lblRA3";
            this.lblRA3.Size = new System.Drawing.Size(39, 18);
            this.lblRA3.TabIndex = 13;
            this.lblRA3.Text = "RA 3";
            // 
            // lblSobre
            // 
            this.lblSobre.AutoSize = true;
            this.lblSobre.Font = new System.Drawing.Font("Microsoft Tai Le", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSobre.Location = new System.Drawing.Point(21, 256);
            this.lblSobre.Name = "lblSobre";
            this.lblSobre.Size = new System.Drawing.Size(48, 18);
            this.lblSobre.TabIndex = 12;
            this.lblSobre.Text = "Sobre";
            // 
            // lblMembro3
            // 
            this.lblMembro3.AutoSize = true;
            this.lblMembro3.Font = new System.Drawing.Font("Microsoft Tai Le", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMembro3.Location = new System.Drawing.Point(21, 215);
            this.lblMembro3.Name = "lblMembro3";
            this.lblMembro3.Size = new System.Drawing.Size(78, 18);
            this.lblMembro3.TabIndex = 11;
            this.lblMembro3.Text = "Membro 3";
            // 
            // lblMembro2
            // 
            this.lblMembro2.AutoSize = true;
            this.lblMembro2.Font = new System.Drawing.Font("Microsoft Tai Le", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMembro2.Location = new System.Drawing.Point(21, 173);
            this.lblMembro2.Name = "lblMembro2";
            this.lblMembro2.Size = new System.Drawing.Size(78, 18);
            this.lblMembro2.TabIndex = 16;
            this.lblMembro2.Text = "Membro 2";
            // 
            // lblMembro1
            // 
            this.lblMembro1.AutoSize = true;
            this.lblMembro1.Font = new System.Drawing.Font("Microsoft Tai Le", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMembro1.Location = new System.Drawing.Point(21, 127);
            this.lblMembro1.Name = "lblMembro1";
            this.lblMembro1.Size = new System.Drawing.Size(78, 18);
            this.lblMembro1.TabIndex = 10;
            this.lblMembro1.Text = "Membro 1";
            // 
            // btnFechar
            // 
            this.btnFechar.Location = new System.Drawing.Point(243, 353);
            this.btnFechar.Name = "btnFechar";
            this.btnFechar.Size = new System.Drawing.Size(75, 23);
            this.btnFechar.TabIndex = 32;
            this.btnFechar.Text = "Fechar";
            this.btnFechar.UseVisualStyleBackColor = true;
            this.btnFechar.Click += new System.EventHandler(this.btnFechar_Click);
            // 
            // frmSobre
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(582, 401);
            this.Controls.Add(this.btnFechar);
            this.Controls.Add(this.txtBoxSobre);
            this.Controls.Add(this.txtBoxRA3);
            this.Controls.Add(this.txtBox2);
            this.Controls.Add(this.txtBoxRA1);
            this.Controls.Add(this.txtBoxMembro1);
            this.Controls.Add(this.txtBoxAtividade);
            this.Controls.Add(this.txtBoxMembro3);
            this.Controls.Add(this.txtBoxMembro2);
            this.Controls.Add(this.txtBoxVersao);
            this.Controls.Add(this.txtBoxProfessora);
            this.Controls.Add(this.txtBoxMateria);
            this.Controls.Add(this.lblVersao);
            this.Controls.Add(this.lblProfessora);
            this.Controls.Add(this.lblAtividade);
            this.Controls.Add(this.lblMateria);
            this.Controls.Add(this.lblRA1);
            this.Controls.Add(this.lblRA2);
            this.Controls.Add(this.lblRA3);
            this.Controls.Add(this.lblSobre);
            this.Controls.Add(this.lblMembro3);
            this.Controls.Add(this.lblMembro2);
            this.Controls.Add(this.lblMembro1);
            this.Name = "frmSobre";
            this.Text = "frmSobre";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox txtBoxSobre;
        private System.Windows.Forms.TextBox txtBoxRA3;
        private System.Windows.Forms.TextBox txtBox2;
        private System.Windows.Forms.TextBox txtBoxRA1;
        private System.Windows.Forms.TextBox txtBoxMembro1;
        private System.Windows.Forms.TextBox txtBoxAtividade;
        private System.Windows.Forms.TextBox txtBoxMembro3;
        private System.Windows.Forms.TextBox txtBoxMembro2;
        private System.Windows.Forms.TextBox txtBoxVersao;
        private System.Windows.Forms.TextBox txtBoxProfessora;
        private System.Windows.Forms.TextBox txtBoxMateria;
        private System.Windows.Forms.Label lblVersao;
        private System.Windows.Forms.Label lblProfessora;
        private System.Windows.Forms.Label lblAtividade;
        private System.Windows.Forms.Label lblMateria;
        private System.Windows.Forms.Label lblRA1;
        private System.Windows.Forms.Label lblRA2;
        private System.Windows.Forms.Label lblRA3;
        private System.Windows.Forms.Label lblSobre;
        private System.Windows.Forms.Label lblMembro3;
        private System.Windows.Forms.Label lblMembro2;
        private System.Windows.Forms.Label lblMembro1;
        private System.Windows.Forms.Button btnFechar;
    }
}