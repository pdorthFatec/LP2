﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PNotebook
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lbMediaPreco.Items.Clear();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            Double[,] listaNotebooks = new Double[3, 3];
            Double[] listaNotebookMedia = new Double[3];
            String valor = "";
            Double valorTemp, soma;

            for(int i = 0; i < 3;  i++)
            {
                soma = 0;
                for (int j = 0; j < 3; j++)
                {
                    valor = Interaction.InputBox($"informe o valor do notebook {i + 1} na loja {j + 1}", "Orçamentos", "", 23, 22);
                    valor = valor.Replace(".", ",");
                    //MessageBox.Show(valor);

                    if (!Double.TryParse(valor, out valorTemp) || valorTemp <= 0)
                    {
                        MessageBox.Show("Valor inválido, digite novamente");
                        j--;
                    } else
                    {
                        listaNotebooks[i, j] = valorTemp;
                        soma += valorTemp;
                    }
                }

                listaNotebookMedia[i] = soma / 3;
            }

            soma = 0;
            String menssagem = "";
            for(int i = 0;i < 3;i++)
            {
                menssagem = $"Notebook:{i + 1}";
                for (int j = 0; j < 3; j++)
                {
                    menssagem = menssagem + $"  Loja{j+1}: {listaNotebooks[i, j].ToString("C2")} ";
                }

                menssagem = menssagem + $"  Média:{listaNotebookMedia[i].ToString("C2")}";
                soma += listaNotebookMedia[i];

                lbMediaPreco.Items.Add(menssagem);
            }

            lbMediaPreco.Items.Add("---------------------------------------------------");
            soma = soma / 3;
            lbMediaPreco.Items.Add($"Media Geral Computadores{soma.ToString("C2")}");

        }
    }
}
