﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {

        double ladoA, ladoB, ladoC;

        public Form1()
        {
            InitializeComponent();
        }

        private void txtLadoA_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != 8)
            {
                //Char[] Numeros = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };
                //bool temNumero = Numeros.Contains(e.KeyChar);

                //if (!temNumero)
                //{
                //    MessageBox.Show("Favor digitar apenas números");
                //    SendKeys.Send("{BACKSPACE}");
                //}

                if (!Char.IsNumber(e.KeyChar))
                {
                    MessageBox.Show("Favor digitar apenas números");
                    SendKeys.Send("{BACKSPACE}");
                }
            }
        }

        private void txtLadoA_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(txtLadoA.Text, out ladoA) && (ladoA > 0))
            {
                MessageBox.Show("Favor informar uma medida maior que zero.");
                txtLadoA.Focus();
            }
        }

        private void txtLadoB_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(txtLadoB.Text, out ladoB) && (ladoB > 0))
            {
                MessageBox.Show("Favor informar uma medida maior que zero.");
                txtLadoB.Focus();
            }
        }

        private void txtLadoC_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(txtLadoC.Text, out ladoC) && (ladoC > 0))
            {
                MessageBox.Show("Favor informar uma medida maior que zero.");
                txtLadoC.Focus();
            }
        }

        private void txtLadoB_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != 8)
            {
                if (!Char.IsNumber(e.KeyChar))
                {
                    MessageBox.Show("Favor digitar apenas números");
                    SendKeys.Send("{BACKSPACE}");
                }
            }
        }

        private void txtLadoC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != 8)
            {
                if (!Char.IsNumber(e.KeyChar))
                {
                    MessageBox.Show("Favor digitar apenas números");
                    SendKeys.Send("{BACKSPACE}");
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            txtResultado.Text = "Aguardando os dados";
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            if(
                (ladoB - ladoC) < ladoA && ladoA < (ladoB + ladoC) &&
                (ladoA - ladoC) < ladoB && ladoB < (ladoA + ladoC) &&
                (ladoA - ladoB) < ladoC && ladoC < (ladoA + ladoB)
            )
            {
                if      (ladoA == ladoB && ladoB == ladoC) { txtResultado.Text = "Equilátero"; } 
                else if (ladoA == ladoB || ladoB == ladoC || ladoC == ladoA) { txtResultado.Text = "Isóceles"; }
                else    { txtResultado.Text = "Escaleno "; }

            } 
            else
            {
                MessageBox.Show("Favor informar uma medidas de um triângulo válida.");
                txtResultado.Text = "Aguardando os dados";
            }
        }
    }
}
