namespace IMC
{
    public partial class Form1 : Form
    {
        double peso = 0;
        double altura = 0;
        double imc = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void txtPeso_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtPeso.Text, out peso))
            {
                MessageBox.Show("Informe um peso v�lido!", "Aten��o",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtPeso.Focus();
            }
            else if (peso <= 0)
            {
                MessageBox.Show("O peso tem que ser maior que zero!", "Aten��o",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtPeso.Focus();
            }
        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtAltura.Text, out altura))
            {
                MessageBox.Show("Informe uma altura v�lida!", "Aten��o",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtAltura.Focus();
            }
            else if (altura <= 0)
            {
                MessageBox.Show("A altura tem que ser maior que zero!", "Aten��o",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtAltura.Focus();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtPeso.Clear();
            txtAltura.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Voc� deseja sair mesmo?", "Sa�da", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (validarCampos()) {
                String imcTxt = "";
                imc = peso / Math.Pow(altura, 2);
                imc = Math.Round(imc, 1);
                txtIMC.Text = imc.ToString("N1");

                if (imc < 18.5)
                {
                    imcTxt = "Classifica��o: MAGREZA - Grau: 0";
                }
                else if (imc < 25.0)
                {
                    imcTxt = "Classifica��o: NORMAL - Grau: 0";
                }
                else if (imc < 30.0)
                {
                    imcTxt = "Classifica��o: SOBREPESO - Grau: I";
                }
                else if (imc < 40.0)
                {
                    imcTxt = "Classifica��o: OBESIDADE - Grau: II";
                }
                else
                {
                    imcTxt = "Classifica��o: OBESIDADE GRAVE - Grau: III";
                }

                txtIMCResultado.Text = imcTxt;
            }
            else
            {
                MessageBox.Show("Favor preencher todas as medidas!");
            }

        }

        private void txtPeso_Enter(object sender, EventArgs e)
        {
            txtPeso.Clear();
        }

        private void txtAltura_Enter(object sender, EventArgs e)
        {
            txtAltura.Clear();
        }

        private bool validarCampos()
        {
            if (txtPeso.Equals("") || txtAltura.Equals("")
                || txtPeso.Text == string.Empty || txtAltura.Text == string.Empty)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
    }
}
