﻿namespace IMC
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtPeso = new TextBox();
            lblPeso = new Label();
            lblAltura = new Label();
            txtAltura = new TextBox();
            lblIMC = new Label();
            txtIMC = new TextBox();
            btnLimpar = new Button();
            btnSair = new Button();
            btnCalcular = new Button();
            txtIMCResultado = new TextBox();
            SuspendLayout();
            // 
            // txtPeso
            // 
            txtPeso.Location = new Point(104, 21);
            txtPeso.Name = "txtPeso";
            txtPeso.Size = new Size(150, 31);
            txtPeso.TabIndex = 0;
            txtPeso.TextAlign = HorizontalAlignment.Right;
            txtPeso.Enter += txtPeso_Enter;
            txtPeso.Validated += txtPeso_Validated;
            // 
            // lblPeso
            // 
            lblPeso.AutoSize = true;
            lblPeso.Location = new Point(21, 27);
            lblPeso.Name = "lblPeso";
            lblPeso.Size = new Size(53, 25);
            lblPeso.TabIndex = 1;
            lblPeso.Text = "Peso:";
            // 
            // lblAltura
            // 
            lblAltura.AutoSize = true;
            lblAltura.Location = new Point(21, 71);
            lblAltura.Name = "lblAltura";
            lblAltura.Size = new Size(59, 25);
            lblAltura.TabIndex = 3;
            lblAltura.Text = "Altura";
            // 
            // txtAltura
            // 
            txtAltura.Location = new Point(104, 71);
            txtAltura.Name = "txtAltura";
            txtAltura.Size = new Size(150, 31);
            txtAltura.TabIndex = 2;
            txtAltura.TextAlign = HorizontalAlignment.Right;
            txtAltura.Enter += txtAltura_Enter;
            txtAltura.Validated += txtAltura_Validated;
            // 
            // lblIMC
            // 
            lblIMC.AutoSize = true;
            lblIMC.Location = new Point(21, 127);
            lblIMC.Name = "lblIMC";
            lblIMC.Size = new Size(48, 25);
            lblIMC.TabIndex = 5;
            lblIMC.Text = "IMC:";
            // 
            // txtIMC
            // 
            txtIMC.Location = new Point(104, 124);
            txtIMC.Name = "txtIMC";
            txtIMC.ReadOnly = true;
            txtIMC.Size = new Size(150, 31);
            txtIMC.TabIndex = 4;
            txtIMC.TextAlign = HorizontalAlignment.Right;
            // 
            // btnLimpar
            // 
            btnLimpar.Location = new Point(297, 27);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(112, 34);
            btnLimpar.TabIndex = 6;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // btnSair
            // 
            btnSair.Location = new Point(297, 98);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(112, 34);
            btnSair.TabIndex = 7;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btnSair_Click;
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(21, 220);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(388, 34);
            btnCalcular.TabIndex = 8;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // txtIMCResultado
            // 
            txtIMCResultado.Location = new Point(21, 170);
            txtIMCResultado.Name = "txtIMCResultado";
            txtIMCResultado.ReadOnly = true;
            txtIMCResultado.Size = new Size(388, 31);
            txtIMCResultado.TabIndex = 9;
            txtIMCResultado.TextAlign = HorizontalAlignment.Center;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(438, 289);
            Controls.Add(txtIMCResultado);
            Controls.Add(btnCalcular);
            Controls.Add(btnSair);
            Controls.Add(btnLimpar);
            Controls.Add(lblIMC);
            Controls.Add(txtIMC);
            Controls.Add(lblAltura);
            Controls.Add(txtAltura);
            Controls.Add(lblPeso);
            Controls.Add(txtPeso);
            Name = "Form1";
            Text = "Cálculo do IMC";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtPeso;
        private Label lblPeso;
        private Label lblAltura;
        private TextBox txtAltura;
        private Label lblIMC;
        private TextBox txtIMC;
        private Button btnLimpar;
        private Button btnSair;
        private Button btnCalcular;
        private TextBox txtIMCResultado;
    }
}
