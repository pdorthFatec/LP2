﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Psalario
{
    public partial class Form1 : Form
    {
        double salario;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double inssAliq, inssDesconto, irpfAliq, irpfDesconto, qtdFilhos, salFamilia, salLiquido;

            // Aliquota do INSS
            if (salario <= 800.47)
            {
                inssAliq = 7.65;
                inssDesconto = salario * inssAliq / 100;
                txtDescInss.Text = inssDesconto.ToString("N2");
                txtAliqInss.Text = inssAliq.ToString("N2");
            } 
            else if (salario <= 1050)
            {
                inssAliq = 8.65;
                inssDesconto = salario * inssAliq / 100;
                txtDescInss.Text = inssDesconto.ToString("N2");
                txtAliqInss.Text = inssAliq.ToString("N2");
            }
            else if (salario <= 1400.77)
            {
                inssAliq = 9;
                inssDesconto = salario * inssAliq / 100;
                txtDescInss.Text = inssDesconto.ToString("N2");
                txtAliqInss.Text = inssAliq.ToString("N2");
            }
            else if (salario <= 2801.56)
            {
                inssAliq = 11;
                inssDesconto = salario * inssAliq / 100;
                txtDescInss.Text = inssDesconto.ToString("N2");
                txtAliqInss.Text = inssAliq.ToString("N2");
            }
            else
            {
                inssAliq = 0;
                inssDesconto = 308.17;
                txtAliqInss.Text = "Teto";
                txtDescInss.Text = inssDesconto.ToString("N2");
            }

            // Aliquota do IRPF
            if (salario <= 1257.12)
            {
                irpfAliq = 0;
                irpfDesconto = 0;
                txtAliqIrpf.Text = "Isento";
                txtDescIrpf.Text = irpfDesconto.ToString("N2");
            }
            else if (salario <= 2512.08)
            {
                irpfAliq = 15;
                irpfDesconto = salario * irpfAliq / 100;
                txtAliqIrpf.Text = irpfAliq.ToString("N2");
                txtDescIrpf.Text = irpfDesconto.ToString("N2");
            }
            else
            {
                irpfAliq = 27.5;
                irpfDesconto = salario * irpfAliq / 100;
                txtAliqIrpf.Text = irpfAliq.ToString("N2");
                txtDescIrpf.Text = irpfDesconto.ToString("N2");
            }

            // Salario familia
            if (salario <= 435.52)
            {
                qtdFilhos = Convert.ToDouble(nudFilhos.Value);
                salFamilia = qtdFilhos * 22.33;
                txtSalFamilia.Text = salFamilia.ToString("N2");
            }
            else if (salario <= 654.61)
            {
                qtdFilhos = Convert.ToDouble(nudFilhos.Value);
                salFamilia = qtdFilhos * 15.74;
                txtSalFamilia.Text = salFamilia.ToString("N2");
            }
            else
            {
                qtdFilhos = Convert.ToDouble(nudFilhos.Value);
                salFamilia = qtdFilhos * 0;
                txtSalFamilia.Text = salFamilia.ToString("N2");
            }

            salLiquido = salario - inssDesconto - irpfDesconto + salFamilia;
            txtSalLiq.Text = salLiquido.ToString("N2");

        }

        private void txtNome_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsNumber(e.KeyChar) || Char.IsPunctuation(e.KeyChar))
            {
                MessageBox.Show("caracter inválido");
                SendKeys.Send("{BACKSPACE}");
            }
        }

        private void mskbxSalario_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(mskbxSalario.Text, out salario) && (salario > 0))
            {
                MessageBox.Show("Favor informar um valor mairo que zero.");
                mskbxSalario.Focus();
            }

            //MessageBox.Show(salario.ToString());
        }

        private void txtNome_Validated(object sender, EventArgs e)
        {
            if (txtNome.Text.Equals("") || txtNome.Text == String.Empty)
            {
                MessageBox.Show("Favor informar um nome.");
                txtNome.Focus();
            }
        }
    }
}
