﻿namespace Psalario
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNome = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.lblSalario = new System.Windows.Forms.Label();
            this.mskbxSalario = new System.Windows.Forms.MaskedTextBox();
            this.lblFilhos = new System.Windows.Forms.Label();
            this.nudFilhos = new System.Windows.Forms.NumericUpDown();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.txtAliqInss = new System.Windows.Forms.TextBox();
            this.lblAliqInss = new System.Windows.Forms.Label();
            this.txtDescInss = new System.Windows.Forms.TextBox();
            this.lblDescInss = new System.Windows.Forms.Label();
            this.txtAliqIrpf = new System.Windows.Forms.TextBox();
            this.lblAliqIrpf = new System.Windows.Forms.Label();
            this.txtDescIrpf = new System.Windows.Forms.TextBox();
            this.lblDescIrpf = new System.Windows.Forms.Label();
            this.txtSalFamilia = new System.Windows.Forms.TextBox();
            this.lblSalFam = new System.Windows.Forms.Label();
            this.txtSalLiq = new System.Windows.Forms.TextBox();
            this.lblSalLiq = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.nudFilhos)).BeginInit();
            this.SuspendLayout();
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(12, 25);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(123, 16);
            this.lblNome.TabIndex = 0;
            this.lblNome.Text = "Nome Funcionário: ";
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(141, 22);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(463, 22);
            this.txtNome.TabIndex = 1;
            this.txtNome.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNome_KeyPress);
            this.txtNome.Validated += new System.EventHandler(this.txtNome_Validated);
            // 
            // lblSalario
            // 
            this.lblSalario.AutoSize = true;
            this.lblSalario.Location = new System.Drawing.Point(48, 50);
            this.lblSalario.Name = "lblSalario";
            this.lblSalario.Size = new System.Drawing.Size(87, 16);
            this.lblSalario.TabIndex = 2;
            this.lblSalario.Text = "Salário Bruto:";
            // 
            // mskbxSalario
            // 
            this.mskbxSalario.Location = new System.Drawing.Point(141, 50);
            this.mskbxSalario.Mask = "99,000.00";
            this.mskbxSalario.Name = "mskbxSalario";
            this.mskbxSalario.Size = new System.Drawing.Size(150, 22);
            this.mskbxSalario.TabIndex = 3;
            this.mskbxSalario.Validated += new System.EventHandler(this.mskbxSalario_Validated);
            // 
            // lblFilhos
            // 
            this.lblFilhos.AutoSize = true;
            this.lblFilhos.Location = new System.Drawing.Point(362, 53);
            this.lblFilhos.Name = "lblFilhos";
            this.lblFilhos.Size = new System.Drawing.Size(116, 16);
            this.lblFilhos.TabIndex = 4;
            this.lblFilhos.Text = "Número de Filhos:";
            // 
            // nudFilhos
            // 
            this.nudFilhos.Location = new System.Drawing.Point(484, 51);
            this.nudFilhos.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.nudFilhos.Name = "nudFilhos";
            this.nudFilhos.Size = new System.Drawing.Size(120, 22);
            this.nudFilhos.TabIndex = 5;
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(15, 78);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(589, 23);
            this.btnCalcular.TabIndex = 6;
            this.btnCalcular.Text = "Verificar Desconto";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // txtAliqInss
            // 
            this.txtAliqInss.Enabled = false;
            this.txtAliqInss.Location = new System.Drawing.Point(167, 119);
            this.txtAliqInss.Name = "txtAliqInss";
            this.txtAliqInss.Size = new System.Drawing.Size(100, 22);
            this.txtAliqInss.TabIndex = 8;
            // 
            // lblAliqInss
            // 
            this.lblAliqInss.AutoSize = true;
            this.lblAliqInss.Location = new System.Drawing.Point(72, 119);
            this.lblAliqInss.Name = "lblAliqInss";
            this.lblAliqInss.Size = new System.Drawing.Size(96, 16);
            this.lblAliqInss.TabIndex = 7;
            this.lblAliqInss.Text = "Alíquota INSS: ";
            // 
            // txtDescInss
            // 
            this.txtDescInss.Enabled = false;
            this.txtDescInss.Location = new System.Drawing.Point(413, 119);
            this.txtDescInss.Name = "txtDescInss";
            this.txtDescInss.Size = new System.Drawing.Size(100, 22);
            this.txtDescInss.TabIndex = 10;
            // 
            // lblDescInss
            // 
            this.lblDescInss.AutoSize = true;
            this.lblDescInss.Location = new System.Drawing.Point(305, 122);
            this.lblDescInss.Name = "lblDescInss";
            this.lblDescInss.Size = new System.Drawing.Size(102, 16);
            this.lblDescInss.TabIndex = 9;
            this.lblDescInss.Text = "Desconto INSS:";
            // 
            // txtAliqIrpf
            // 
            this.txtAliqIrpf.Enabled = false;
            this.txtAliqIrpf.Location = new System.Drawing.Point(167, 150);
            this.txtAliqIrpf.Name = "txtAliqIrpf";
            this.txtAliqIrpf.Size = new System.Drawing.Size(100, 22);
            this.txtAliqIrpf.TabIndex = 12;
            // 
            // lblAliqIrpf
            // 
            this.lblAliqIrpf.AutoSize = true;
            this.lblAliqIrpf.Location = new System.Drawing.Point(72, 150);
            this.lblAliqIrpf.Name = "lblAliqIrpf";
            this.lblAliqIrpf.Size = new System.Drawing.Size(95, 16);
            this.lblAliqIrpf.TabIndex = 11;
            this.lblAliqIrpf.Text = "Alíquota IRPF: ";
            // 
            // txtDescIrpf
            // 
            this.txtDescIrpf.Enabled = false;
            this.txtDescIrpf.Location = new System.Drawing.Point(413, 147);
            this.txtDescIrpf.Name = "txtDescIrpf";
            this.txtDescIrpf.Size = new System.Drawing.Size(100, 22);
            this.txtDescIrpf.TabIndex = 14;
            // 
            // lblDescIrpf
            // 
            this.lblDescIrpf.AutoSize = true;
            this.lblDescIrpf.Location = new System.Drawing.Point(306, 150);
            this.lblDescIrpf.Name = "lblDescIrpf";
            this.lblDescIrpf.Size = new System.Drawing.Size(101, 16);
            this.lblDescIrpf.TabIndex = 13;
            this.lblDescIrpf.Text = "Desconto IRPF:";
            // 
            // txtSalFamilia
            // 
            this.txtSalFamilia.Enabled = false;
            this.txtSalFamilia.Location = new System.Drawing.Point(167, 178);
            this.txtSalFamilia.Name = "txtSalFamilia";
            this.txtSalFamilia.Size = new System.Drawing.Size(100, 22);
            this.txtSalFamilia.TabIndex = 16;
            // 
            // lblSalFam
            // 
            this.lblSalFam.AutoSize = true;
            this.lblSalFam.Location = new System.Drawing.Point(61, 181);
            this.lblSalFam.Name = "lblSalFam";
            this.lblSalFam.Size = new System.Drawing.Size(100, 16);
            this.lblSalFam.TabIndex = 15;
            this.lblSalFam.Text = "Salário Família:";
            // 
            // txtSalLiq
            // 
            this.txtSalLiq.Enabled = false;
            this.txtSalLiq.Location = new System.Drawing.Point(167, 206);
            this.txtSalLiq.Name = "txtSalLiq";
            this.txtSalLiq.Size = new System.Drawing.Size(100, 22);
            this.txtSalLiq.TabIndex = 18;
            // 
            // lblSalLiq
            // 
            this.lblSalLiq.AutoSize = true;
            this.lblSalLiq.Location = new System.Drawing.Point(61, 206);
            this.lblSalLiq.Name = "lblSalLiq";
            this.lblSalLiq.Size = new System.Drawing.Size(100, 16);
            this.lblSalLiq.TabIndex = 17;
            this.lblSalLiq.Text = "Salário Líquido:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(631, 243);
            this.Controls.Add(this.txtSalLiq);
            this.Controls.Add(this.lblSalLiq);
            this.Controls.Add(this.txtSalFamilia);
            this.Controls.Add(this.lblSalFam);
            this.Controls.Add(this.txtDescIrpf);
            this.Controls.Add(this.lblDescIrpf);
            this.Controls.Add(this.txtAliqIrpf);
            this.Controls.Add(this.lblAliqIrpf);
            this.Controls.Add(this.txtDescInss);
            this.Controls.Add(this.lblDescInss);
            this.Controls.Add(this.txtAliqInss);
            this.Controls.Add(this.lblAliqInss);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.nudFilhos);
            this.Controls.Add(this.lblFilhos);
            this.Controls.Add(this.mskbxSalario);
            this.Controls.Add(this.lblSalario);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.lblNome);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.nudFilhos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Label lblSalario;
        private System.Windows.Forms.MaskedTextBox mskbxSalario;
        private System.Windows.Forms.Label lblFilhos;
        private System.Windows.Forms.NumericUpDown nudFilhos;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.TextBox txtAliqInss;
        private System.Windows.Forms.Label lblAliqInss;
        private System.Windows.Forms.TextBox txtDescInss;
        private System.Windows.Forms.Label lblDescInss;
        private System.Windows.Forms.TextBox txtAliqIrpf;
        private System.Windows.Forms.Label lblAliqIrpf;
        private System.Windows.Forms.TextBox txtDescIrpf;
        private System.Windows.Forms.Label lblDescIrpf;
        private System.Windows.Forms.TextBox txtSalFamilia;
        private System.Windows.Forms.Label lblSalFam;
        private System.Windows.Forms.TextBox txtSalLiq;
        private System.Windows.Forms.Label lblSalLiq;
    }
}

