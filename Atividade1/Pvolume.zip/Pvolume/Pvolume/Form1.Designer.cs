﻿namespace Pvolume
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtRaio = new TextBox();
            txtAltura = new TextBox();
            label2 = new Label();
            txtVolume = new TextBox();
            label3 = new Label();
            btnCalcular = new Button();
            btnFechar = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(110, 23);
            label1.Name = "label1";
            label1.Size = new Size(47, 25);
            label1.TabIndex = 0;
            label1.Text = "Raio";
            // 
            // txtRaio
            // 
            txtRaio.Location = new Point(163, 20);
            txtRaio.Name = "txtRaio";
            txtRaio.Size = new Size(150, 31);
            txtRaio.TabIndex = 1;
            txtRaio.Validated += txtRaio_Validated;
            // 
            // txtAltura
            // 
            txtAltura.Location = new Point(163, 57);
            txtAltura.Name = "txtAltura";
            txtAltura.Size = new Size(150, 31);
            txtAltura.TabIndex = 3;
            txtAltura.Validated += txtAltura_Validated;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(97, 60);
            label2.Name = "label2";
            label2.Size = new Size(59, 25);
            label2.TabIndex = 2;
            label2.Text = "Altura";
            // 
            // txtVolume
            // 
            txtVolume.Enabled = false;
            txtVolume.Location = new Point(163, 94);
            txtVolume.Name = "txtVolume";
            txtVolume.Size = new Size(150, 31);
            txtVolume.TabIndex = 5;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(85, 97);
            label3.Name = "label3";
            label3.Size = new Size(72, 25);
            label3.TabIndex = 4;
            label3.Text = "Volume";
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(85, 148);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(112, 34);
            btnCalcular.TabIndex = 6;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // btnFechar
            // 
            btnFechar.Location = new Point(220, 148);
            btnFechar.Name = "btnFechar";
            btnFechar.Size = new Size(112, 34);
            btnFechar.TabIndex = 7;
            btnFechar.Text = "Fechar";
            btnFechar.UseVisualStyleBackColor = true;
            btnFechar.Click += btnFechar_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(433, 210);
            Controls.Add(btnFechar);
            Controls.Add(btnCalcular);
            Controls.Add(txtVolume);
            Controls.Add(label3);
            Controls.Add(txtAltura);
            Controls.Add(label2);
            Controls.Add(txtRaio);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Cálculo do Volume do Cilindro";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtRaio;
        private TextBox txtAltura;
        private Label label2;
        private TextBox txtVolume;
        private Label label3;
        private Button btnCalcular;
        private Button btnFechar;
    }
}
