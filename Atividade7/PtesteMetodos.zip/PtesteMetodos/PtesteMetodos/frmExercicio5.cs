﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PtesteMetodos
{
    public partial class frmExercicio5 : Form
    {
        int numero1, numero2;

        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            Random sorteador = new Random();

            if (numero2 < numero1)
            {
                MessageBox.Show("Número 1 não pode ser menor que o Número 2");
                txtNumero1.Focus();
            }
            else
            {
                MessageBox.Show($"Número sorteado entra {numero1} e {numero2}: {sorteador.Next(numero1, numero2)}");
            }
        }

        private void txtNumero2_Validated(object sender, EventArgs e)
        {
            if (!int.TryParse(txtNumero2.Text, out numero2))
            {
                MessageBox.Show("Digite um número válido");
                txtNumero2.Focus();
            }
        }

        private void txtNumero1_Validated(object sender, EventArgs e)
        {
            if (!int.TryParse(txtNumero1.Text, out numero1))
            {
                MessageBox.Show("Digite um número válido");
                txtNumero1.Focus();
            }
        }
    }
}
