﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PTesteMatrizes
{
    public partial class frnExercicio04 : Form
    {
        public frnExercicio04()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string auxiliar;
            int quantidade=0;

            for (int i = 0; i < 1; i++)
            {
                auxiliar = Interaction.InputBox("Informe a quantidade de nomes para validação", "Entrada de dados");
                if(!int.TryParse(auxiliar, out quantidade) || (quantidade < 1 || quantidade > 10))
                {
                    MessageBox.Show("Informe uma quantidade entre de 1 a 10.");
                    i--;
                }
            }

            string[,] lista = new string[quantidade,2];

            for(int i = 0; i < quantidade; i++)
            {
                auxiliar = Interaction.InputBox($"Informe o {i + 1} nome.", "Entrada de dados");
                if (auxiliar == "")
                {
                    MessageBox.Show("Informe um nome válido");
                    i--;
                } else
                {
                    lista[i,0] = auxiliar;
                    lista[i,1] = validaCaracter(auxiliar);
                }
            }

            for(int i = 0;i < quantidade; i++)
            {
                listBoxName.Items.Add($"o nome {lista[i,0]} tem {lista[i,1]} caraceter(es)");
            }
            /// listBoxName.itens.add(""); --- Para o exercício 04
        }

        private String validaCaracter(String caracter)
        {
            int quantidade = caracter.Replace(" ","").Length;
            return quantidade.ToString();
        }
    }
}
