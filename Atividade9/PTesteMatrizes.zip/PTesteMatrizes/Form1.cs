﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PTesteMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercicio01_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar;

            for (int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i + 1} número", "Entrada de dados");

                if(auxiliar == "")
                {
                    break; // ou return
                }

                if(!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número inválido");
                    i--;
                }
            }

            auxiliar = "";
            Array.Reverse(vetor);

            foreach (int i in vetor)
            {
                auxiliar += i + "\n";
            }

            MessageBox.Show(auxiliar);
        }

        private void btnExercicio02_Click(object sender, EventArgs e)
        {
            ArrayList alunos01 = new ArrayList();
            alunos01.Add("Ana");
            alunos01.Add("André");
            alunos01.Add("Débora");
            alunos01.Add("Fátima");
            alunos01.Add("João");
            alunos01.Add("Janete");
            alunos01.Add("Otávio");
            alunos01.Add("Marcelo");
            alunos01.Add("Pedro");
            alunos01.Add("Thais");

            ArrayList alunos02 = new ArrayList() 
                {"Ana", "André", "Débora", "Fátima", "João", 
                 "Janete", "Otávio", "Marcelo", "Pedro", "Thais" };

            string mensagem01 = "";
            foreach (string i in alunos01)
            {
                mensagem01 += i + " ";
            }

            string mensagem02 = "";
            foreach (string i in alunos02)
            {
                mensagem02 += i + " ";
            }

            MessageBox.Show(mensagem01);
            MessageBox.Show(mensagem02);

            alunos01.Remove("Otávio");
            alunos02.Remove("Otávio");

            mensagem01 = "";
            foreach (string i in alunos01)
            {
                mensagem01 += i + " ";
            }

            mensagem02 = "";
            foreach (string i in alunos02)
            {
                mensagem02 += i + " ";
            }

            MessageBox.Show(mensagem01);
            MessageBox.Show(mensagem02);
        }

        private void btnExercicio03_Click(object sender, EventArgs e)
        {
            Double[,] notas = new double[20, 3];
            double nota;
            string auxiliar;

            for (int a = 0; a < 20; a++)
            {
                for (int n = 0; n < 3; n++)
                {
                    auxiliar = Interaction.InputBox($"Digite a nota {n + 1} do Aluno {a + 1}", "Entrada de dados");
                    if (!Double.TryParse(auxiliar, out nota) || (nota < 0 || nota > 10))
                    {
                        MessageBox.Show("Informe uma nota válida, de 0 a 10.");
                        n--;
                    } else
                    {
                        notas[a, n] = nota;
                    }
                }
            }

            String mensagem = "";
            for (int a = 0; a < 20; a++)
            {
                nota = 0.0;
                for (int n = 0; n < 3; n++)
                {
                    nota += notas[a, n];
                }
                nota = nota / 3;
                mensagem += $"Aluno {a + 1}: média = {nota.ToString("N2")}\n";
            }

            MessageBox.Show(mensagem);
        }

        private void btnExercicio04_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frnExercicio04>().Count() > 0)
            {
                //Application.OpenForms["frnExercicio04"].BringToFront();
                Application.OpenForms["frnExercicio04"]?.BringToFront();
            }
            else
            {
                frnExercicio04 objFrm = new frnExercicio04();
                //objFrm.MdiParent = this;
                //objFrm.WindowState = FormWindowState.Maximized;
                objFrm.Show();
            }
        }

        private void btnExercicio05_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frnExercicio05>().Count() > 0)
            {
                //Application.OpenForms["frnExercicio05"].BringToFront();
                Application.OpenForms["frnExercicio05"]?.BringToFront();
            }
            else
            {
                frnExercicio05 objFrm = new frnExercicio05();
                //objFrm.MdiParent = this;
                //objFrm.WindowState = FormWindowState.Maximized;
                objFrm.Show();
            }
        }
    }
}
