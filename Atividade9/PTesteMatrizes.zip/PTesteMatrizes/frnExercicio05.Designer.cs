﻿namespace PTesteMatrizes
{
    partial class frnExercicio05
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnValidar = new System.Windows.Forms.Button();
            this.listBoxValidar = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnValidar
            // 
            this.btnValidar.Location = new System.Drawing.Point(31, 83);
            this.btnValidar.Name = "btnValidar";
            this.btnValidar.Size = new System.Drawing.Size(193, 173);
            this.btnValidar.TabIndex = 0;
            this.btnValidar.Text = "Validar";
            this.btnValidar.UseVisualStyleBackColor = true;
            this.btnValidar.Click += new System.EventHandler(this.btnValidar_Click);
            // 
            // listBoxValidar
            // 
            this.listBoxValidar.FormattingEnabled = true;
            this.listBoxValidar.ItemHeight = 16;
            this.listBoxValidar.Location = new System.Drawing.Point(251, 12);
            this.listBoxValidar.Name = "listBoxValidar";
            this.listBoxValidar.Size = new System.Drawing.Size(371, 324);
            this.listBoxValidar.TabIndex = 1;
            // 
            // frnExercicio05
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(637, 350);
            this.Controls.Add(this.listBoxValidar);
            this.Controls.Add(this.btnValidar);
            this.Name = "frnExercicio05";
            this.Text = "frnExercicio05";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnValidar;
        private System.Windows.Forms.ListBox listBoxValidar;
    }
}