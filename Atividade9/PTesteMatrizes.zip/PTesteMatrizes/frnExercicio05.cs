﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PTesteMatrizes
{
    public partial class frnExercicio05 : Form
    {
        public frnExercicio05()
        {
            InitializeComponent();
        }

        private void btnValidar_Click(object sender, EventArgs e)
        {
            string[] gabarito = new string[10] { "A","B","C","D","E", "A", "B", "C", "D", "E" };
            string auxiliar;
            int quantidade = 0;

            for (int i = 0; i < 1; i++)
            {
                auxiliar = Interaction.InputBox("Informe a quantidade de questões para validação", "Entrada de dados");
                if (!int.TryParse(auxiliar, out quantidade) || (quantidade < 1 || quantidade > 10))
                {
                    MessageBox.Show("Informe uma quantidade entre de 1 a 10.");
                    i--;
                }
            }

            string[] lista = new string[quantidade];
            for (int i = 0; i < quantidade; i++)
            {
                auxiliar = Interaction.InputBox($"Informe a {i + 1} resposta.", "Entrada de dados");
                if (!validaResposta(auxiliar.ToUpper()))
                {
                    MessageBox.Show("Informe uma resposta válida (A, B, C, D ou E)");
                    i--;
                }
                else
                {
                    lista[i] = auxiliar.ToUpper();
                }
            }

            String mensagem;
            for (int i = 0; i < quantidade; i++)
            {
                if (lista[i].Equals(gabarito[i]))
                {
                    mensagem = $"Item {i + 1} - Acertou ({lista[i]})";
                } else
                {
                    mensagem = $"Item {i + 1} - Errou (Informou: {lista[i]} - Esperado: {gabarito[i]})";
                }
                
                listBoxValidar.Items.Add(mensagem);
            }
        }

        private bool validaResposta(String resposta)
        {
            bool validaResposta = false;

            if (resposta.Equals("A") || 
                resposta.Equals("B") ||
                resposta.Equals("C") ||
                resposta.Equals("D") ||
                resposta.Equals("E") )
            {
                validaResposta = true;
            }

            return validaResposta;
        }
    }
}
