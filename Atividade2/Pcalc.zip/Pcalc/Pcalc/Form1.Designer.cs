﻿namespace Pcalc
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblNumero01 = new Label();
            txtNumero1 = new TextBox();
            txtNumero2 = new TextBox();
            lblNumero02 = new Label();
            txtNumero3 = new TextBox();
            lblNumero03 = new Label();
            btnLimpar = new Button();
            btnSair = new Button();
            btnSomar = new Button();
            btnSubtrair = new Button();
            btnDivisao = new Button();
            btnMultiplicacao = new Button();
            SuspendLayout();
            // 
            // lblNumero01
            // 
            lblNumero01.AutoSize = true;
            lblNumero01.Location = new Point(30, 31);
            lblNumero01.Name = "lblNumero01";
            lblNumero01.Size = new Size(102, 25);
            lblNumero01.TabIndex = 0;
            lblNumero01.Text = "Número 01";
            // 
            // txtNumero1
            // 
            txtNumero1.Location = new Point(138, 28);
            txtNumero1.Name = "txtNumero1";
            txtNumero1.Size = new Size(150, 31);
            txtNumero1.TabIndex = 1;
            txtNumero1.TextAlign = HorizontalAlignment.Right;
            txtNumero1.Enter += txtNumero1_Enter;
            txtNumero1.Validated += txtNumero1_Validated;
            // 
            // txtNumero2
            // 
            txtNumero2.Location = new Point(138, 75);
            txtNumero2.Name = "txtNumero2";
            txtNumero2.Size = new Size(150, 31);
            txtNumero2.TabIndex = 3;
            txtNumero2.TextAlign = HorizontalAlignment.Right;
            txtNumero2.Enter += txtNumero2_Enter;
            txtNumero2.Validated += txtNumero2_Validated;
            // 
            // lblNumero02
            // 
            lblNumero02.AutoSize = true;
            lblNumero02.Location = new Point(30, 78);
            lblNumero02.Name = "lblNumero02";
            lblNumero02.Size = new Size(102, 25);
            lblNumero02.TabIndex = 2;
            lblNumero02.Text = "Número 02";
            // 
            // txtNumero3
            // 
            txtNumero3.Location = new Point(138, 126);
            txtNumero3.Name = "txtNumero3";
            txtNumero3.ReadOnly = true;
            txtNumero3.Size = new Size(150, 31);
            txtNumero3.TabIndex = 5;
            txtNumero3.TextAlign = HorizontalAlignment.Right;
            // 
            // lblNumero03
            // 
            lblNumero03.AutoSize = true;
            lblNumero03.Location = new Point(30, 126);
            lblNumero03.Name = "lblNumero03";
            lblNumero03.Size = new Size(90, 25);
            lblNumero03.TabIndex = 4;
            lblNumero03.Text = "Resultado";
            // 
            // btnLimpar
            // 
            btnLimpar.Location = new Point(342, 26);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(112, 34);
            btnLimpar.TabIndex = 6;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // btnSair
            // 
            btnSair.Location = new Point(342, 90);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(112, 34);
            btnSair.TabIndex = 7;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btnSair_Click;
            // 
            // btnSomar
            // 
            btnSomar.Location = new Point(71, 180);
            btnSomar.Name = "btnSomar";
            btnSomar.Size = new Size(54, 46);
            btnSomar.TabIndex = 8;
            btnSomar.Text = "+";
            btnSomar.UseVisualStyleBackColor = true;
            btnSomar.Click += btnSomar_Click;
            // 
            // btnSubtrair
            // 
            btnSubtrair.Location = new Point(154, 180);
            btnSubtrair.Name = "btnSubtrair";
            btnSubtrair.Size = new Size(51, 46);
            btnSubtrair.TabIndex = 9;
            btnSubtrair.Text = "-";
            btnSubtrair.UseVisualStyleBackColor = true;
            btnSubtrair.Click += btnSubtrair_Click;
            // 
            // btnDivisao
            // 
            btnDivisao.Location = new Point(319, 180);
            btnDivisao.Name = "btnDivisao";
            btnDivisao.Size = new Size(51, 46);
            btnDivisao.TabIndex = 11;
            btnDivisao.Text = "/";
            btnDivisao.UseVisualStyleBackColor = true;
            btnDivisao.Click += btnDivisao_Click;
            // 
            // btnMultiplicacao
            // 
            btnMultiplicacao.Location = new Point(236, 180);
            btnMultiplicacao.Name = "btnMultiplicacao";
            btnMultiplicacao.Size = new Size(54, 46);
            btnMultiplicacao.TabIndex = 10;
            btnMultiplicacao.Text = "*";
            btnMultiplicacao.UseVisualStyleBackColor = true;
            btnMultiplicacao.Click += btnMultiplicacao_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(491, 276);
            Controls.Add(btnDivisao);
            Controls.Add(btnMultiplicacao);
            Controls.Add(btnSubtrair);
            Controls.Add(btnSomar);
            Controls.Add(btnSair);
            Controls.Add(btnLimpar);
            Controls.Add(txtNumero3);
            Controls.Add(lblNumero03);
            Controls.Add(txtNumero2);
            Controls.Add(lblNumero02);
            Controls.Add(txtNumero1);
            Controls.Add(lblNumero01);
            Name = "Form1";
            Text = "Calculadora";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblNumero01;
        private TextBox txtNumero1;
        private TextBox txtNumero2;
        private Label lblNumero02;
        private TextBox txtNumero3;
        private Label lblNumero03;
        private Button btnLimpar;
        private Button btnSair;
        private Button btnSomar;
        private Button btnSubtrair;
        private Button btnDivisao;
        private Button btnMultiplicacao;
    }
}
