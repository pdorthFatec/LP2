namespace Pcalc
{
    public partial class Form1 : Form
    {
        double numero1 = 0;
        double numero2 = 0;
        double numero3 = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Voc� deseja sair mesmo?", "Sa�da", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Text = "0";
            txtNumero2.Text = "0";
            txtNumero3.Clear();
        }

        private void txtNumero1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNumero1.Text, out numero1))
            {
                MessageBox.Show("N�mero 1 inv�lido");
                txtNumero1.Focus();
            }
        }

        private void txtNumero2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNumero2.Text, out numero2))
            {
                MessageBox.Show("N�mero 2 inv�lido");
                txtNumero2.Focus();
            }
        }

        private void btnSomar_Click(object sender, EventArgs e)
        {
            numero3 = numero1 + numero2;
            txtNumero3.Text = numero3.ToString();
        }

        private void btnMultiplicacao_Click(object sender, EventArgs e)
        {
            numero3 = numero1 * numero2;
            txtNumero3.Text = numero3.ToString();
        }

        private void btnDivisao_Click(object sender, EventArgs e)
        {

            if (numero2 != 0)
            {
                numero3 = numero1 / numero2;
                txtNumero3.Text = numero3.ToString();
            }
            else
            {
                MessageBox.Show("Imposs�vel dividir por zero", "Aten��o",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnSubtrair_Click(object sender, EventArgs e)
        {
            numero3 = numero1 - numero2;
            txtNumero3.Text = numero3.ToString();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            txtNumero1.Text = "0";
            txtNumero2.Text = "0";
        }

        private void txtNumero1_Enter(object sender, EventArgs e)
        {
            txtNumero1.Clear();
        }

        private void txtNumero2_Enter(object sender, EventArgs e)
        {
            txtNumero2.Clear();
        }
    }
}
