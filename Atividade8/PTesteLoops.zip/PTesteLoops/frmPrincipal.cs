﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteLoops
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void exercício01ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio1>().Count() > 0)
            {
                //Application.OpenForms["frmExercicio1"].BringToFront();
                Application.OpenForms["frmExercicio1"]?.BringToFront();
            }
            else
            {
                frmExercicio1 objFrm = new frmExercicio1();
                objFrm.MdiParent = this;
                objFrm.WindowState = FormWindowState.Maximized;
                objFrm.Show();
            }
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void exercício02ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio2>().Count() > 0)
            {
                Application.OpenForms["frmExercicio2"]?.BringToFront();
            }
            else
            {
                frmExercicio2 objFrm = new frmExercicio2();
                objFrm.MdiParent = this;
                objFrm.WindowState = FormWindowState.Maximized;
                objFrm.Show();
            }
        }

        private void exercício03ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio3>().Count() > 0)
            {
                Application.OpenForms["frmExercicio3"]?.BringToFront();
            }
            else
            {
                frmExercicio3 objFrm = new frmExercicio3();
                objFrm.MdiParent = this;
                objFrm.WindowState = FormWindowState.Maximized;
                objFrm.Show();
            }
        }

        private void exercício04ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio4>().Count() > 0)
            {
                Application.OpenForms["frmExercicio4"]?.BringToFront();
            }
            else
            {
                frmExercicio4 objFrm = new frmExercicio4();
                objFrm.MdiParent = this;
                objFrm.WindowState = FormWindowState.Maximized;
                objFrm.Show();
            }
        }
    }
}
