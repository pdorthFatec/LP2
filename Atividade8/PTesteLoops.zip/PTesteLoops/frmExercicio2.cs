﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteLoops
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            int Quantidade = 0;
            double soma = 0;

            if (!int.TryParse(txtQtd.Text, out Quantidade) && (Quantidade > 0))
            {
                MessageBox.Show("Favor informar um número válido.");
                txtQtd.Focus();
            } else
            {
                soma = 0;
            }

            for(int i = 0;  i < Quantidade; i++) 
            {
                double valor = 1 / (double) (i+1) ;
                soma += valor;
            }

            MessageBox.Show("A soma é: " + soma.ToString("N2"));
        }
    }
}
