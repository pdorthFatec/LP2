﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteLoops
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            char[] vetor = txtFrase.Text.ToString().ToUpper().Replace(" ", "").ToCharArray();

            string stringOriginal = new String(vetor);

            Array.Reverse(vetor);
            string stringPosterior = new String(vetor);

            String mensagem = "";
            if(stringPosterior.Equals(stringOriginal)) 
            {
                mensagem = "Frase palíndromo";
            } else {
                mensagem = "Frase não palíndromo";
            }

            MessageBox.Show(mensagem);

        }
    }
}
