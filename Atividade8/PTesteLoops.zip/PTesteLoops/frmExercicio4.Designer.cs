﻿namespace PTesteLoops
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblMatricula = new System.Windows.Forms.Label();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblProducao = new System.Windows.Forms.Label();
            this.lblSalario = new System.Windows.Forms.Label();
            this.lblGratificacao = new System.Windows.Forms.Label();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.mskdProducao = new System.Windows.Forms.MaskedTextBox();
            this.mskdSalario = new System.Windows.Forms.MaskedTextBox();
            this.mskdGratificacao = new System.Windows.Forms.MaskedTextBox();
            this.SuspendLayout();
            // 
            // lblMatricula
            // 
            this.lblMatricula.AutoSize = true;
            this.lblMatricula.Location = new System.Drawing.Point(31, 28);
            this.lblMatricula.Name = "lblMatricula";
            this.lblMatricula.Size = new System.Drawing.Size(53, 13);
            this.lblMatricula.TabIndex = 0;
            this.lblMatricula.Text = "Matricula:";
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(90, 25);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(100, 20);
            this.txtMatricula.TabIndex = 1;
            this.txtMatricula.Validated += new System.EventHandler(this.txtMatricula_Validated);
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(90, 51);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(461, 20);
            this.txtNome.TabIndex = 3;
            this.txtNome.Validated += new System.EventHandler(this.txtNome_Validated);
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(43, 54);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(41, 13);
            this.lblNome.TabIndex = 2;
            this.lblNome.Text = "Nome: ";
            // 
            // lblProducao
            // 
            this.lblProducao.AutoSize = true;
            this.lblProducao.Location = new System.Drawing.Point(25, 80);
            this.lblProducao.Name = "lblProducao";
            this.lblProducao.Size = new System.Drawing.Size(59, 13);
            this.lblProducao.TabIndex = 4;
            this.lblProducao.Text = "Produção: ";
            // 
            // lblSalario
            // 
            this.lblSalario.AutoSize = true;
            this.lblSalario.Location = new System.Drawing.Point(39, 106);
            this.lblSalario.Name = "lblSalario";
            this.lblSalario.Size = new System.Drawing.Size(45, 13);
            this.lblSalario.TabIndex = 6;
            this.lblSalario.Text = "Salário: ";
            // 
            // lblGratificacao
            // 
            this.lblGratificacao.AutoSize = true;
            this.lblGratificacao.Location = new System.Drawing.Point(17, 132);
            this.lblGratificacao.Name = "lblGratificacao";
            this.lblGratificacao.Size = new System.Drawing.Size(67, 13);
            this.lblGratificacao.TabIndex = 8;
            this.lblGratificacao.Text = "Gratificação:";
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(476, 122);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(75, 23);
            this.btnCalcular.TabIndex = 10;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // mskdProducao
            // 
            this.mskdProducao.Location = new System.Drawing.Point(90, 77);
            this.mskdProducao.Mask = "999";
            this.mskdProducao.Name = "mskdProducao";
            this.mskdProducao.Size = new System.Drawing.Size(100, 20);
            this.mskdProducao.TabIndex = 5;
            this.mskdProducao.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.mskdProducao.Validated += new System.EventHandler(this.mskdProducao_Validated);
            // 
            // mskdSalario
            // 
            this.mskdSalario.Location = new System.Drawing.Point(90, 103);
            this.mskdSalario.Mask = "$999,999.00";
            this.mskdSalario.Name = "mskdSalario";
            this.mskdSalario.Size = new System.Drawing.Size(100, 20);
            this.mskdSalario.TabIndex = 7;
            this.mskdSalario.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.mskdSalario.Validated += new System.EventHandler(this.mskdSalario_Validated);
            // 
            // mskdGratificacao
            // 
            this.mskdGratificacao.Location = new System.Drawing.Point(90, 129);
            this.mskdGratificacao.Mask = "$999,999.00";
            this.mskdGratificacao.Name = "mskdGratificacao";
            this.mskdGratificacao.Size = new System.Drawing.Size(100, 20);
            this.mskdGratificacao.TabIndex = 9;
            this.mskdGratificacao.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.mskdGratificacao.Validated += new System.EventHandler(this.mskdGratificacao_Validated);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(603, 171);
            this.Controls.Add(this.mskdGratificacao);
            this.Controls.Add(this.mskdSalario);
            this.Controls.Add(this.mskdProducao);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.lblGratificacao);
            this.Controls.Add(this.lblSalario);
            this.Controls.Add(this.lblProducao);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.txtMatricula);
            this.Controls.Add(this.lblMatricula);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMatricula;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblProducao;
        private System.Windows.Forms.Label lblSalario;
        private System.Windows.Forms.Label lblGratificacao;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.MaskedTextBox mskdProducao;
        private System.Windows.Forms.MaskedTextBox mskdSalario;
        private System.Windows.Forms.MaskedTextBox mskdGratificacao;
    }
}