﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteLoops
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnContar_Click(object sender, EventArgs e)
        {
            char[] vetor = rchtxtFrase.ToString().Trim().ToCharArray();
            int quantidade = 0, tamanho, i = 0;
            tamanho = vetor.Length -1;

            while (tamanho!=0)
            {
                if (Char.IsWhiteSpace(vetor[i]))
                {
                    quantidade++;
                }
                tamanho--;
                i++;
            }

            MessageBox.Show("Quantidades de espaços encontrados: " + (quantidade - 2));
        }

        private void btnContarR_Click(object sender, EventArgs e)
        {
            char[] vetor = rchtxtFrase.ToString().Trim().ToUpper().ToCharArray();

            //string teste = new String(vetor);
            //MessageBox.Show(teste);

            int quantidade = 0;

            foreach(Char letra in vetor)
            {
                if (letra == 'R')
                {
                    quantidade++;
                }
            }

            MessageBox.Show("Quantidades de R ou r encontrados: " + (quantidade -2) );
        }

        private void btnComparar_Click(object sender, EventArgs e)
        {
            char[] vetor = rchtxtFrase.ToString().Trim().ToUpper().ToCharArray();

            int quantidade = 0, j = 1;

            for (int i = 0; i < (vetor.Length - 1); i++)
            {
                if (vetor[i] == vetor[j])
                {
                    quantidade++;
                }

                j++;
            }

            MessageBox.Show("Quantidades de Letras repetidas: " + (quantidade));
        }
    }
}
