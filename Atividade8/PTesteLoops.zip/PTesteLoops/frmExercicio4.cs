﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteLoops
{
    public partial class frmExercicio4 : Form
    {
        double producao = 0.0, salario = 0.0, gratificacao = 0.0, salarioBruto = 0.0;

        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            // Valida campos
            ValidaProducao();
            ValidaSalario();
            ValidaGratificacao();

            int b = 0, c = 0, d = 0;
            string salarioBrutoTXT = "";

            if (producao >= 100.0)
                b = 1;

            if (producao >= 120.0)
                c = 1;

            if (producao >= 150.0)
                d = 1;

            salarioBruto = salario + (salario * ((0.05 * b) + (0.1 * c) + (0.1 * d))) + gratificacao;


            if(salarioBruto <= 7000.0)
            {
                salarioBrutoTXT = salarioBruto.ToString("N2");
            } else
            {
                if(producao >= 150.0 && gratificacao > 0.0)
                {
                    salarioBrutoTXT = salarioBruto.ToString("N2");
                } else
                {
                    salarioBrutoTXT = salario.ToString("N2");
                }
            }

            MessageBox.Show("Salário Bruto: " + salarioBrutoTXT);
        }

        private void txtMatricula_Validated(object sender, EventArgs e)
        {
            if(txtMatricula.Text == "")
            {
                MessageBox.Show("Favor informar uma matrícula.");
                txtMatricula.Focus();
            }
        }

        private void txtNome_Validated(object sender, EventArgs e)
        {
            if (txtNome.Text == "")
            {
                MessageBox.Show("Favor informar um nome.");
                txtNome.Focus();
            }
        }

        private void mskdProducao_Validated(object sender, EventArgs e)
        {
            ValidaProducao();

        }

        private void mskdSalario_Validated(object sender, EventArgs e)
        {
            ValidaSalario();
        }

        private void mskdGratificacao_Validated(object sender, EventArgs e)
        {
            ValidaGratificacao();
        }

        void ValidaProducao()
        {
            if (!Double.TryParse(mskdProducao.Text, out producao))
            {
                MessageBox.Show("Favor infomar uma quantidade.");
                mskdProducao.Focus();
            }
        }

        void ValidaSalario()
        {
            if (!Double.TryParse(mskdSalario.Text.ToString().Replace("R$","").Replace(".", ""), out salario))
            {
                MessageBox.Show("Favor infomar um salário.");

                mskdSalario.Focus();
            }
        }

        void ValidaGratificacao()
        {
            if (!Double.TryParse(mskdGratificacao.Text.ToString().Replace("R$", "").Replace(".", ""), out gratificacao))
            {
                MessageBox.Show("Favor infomar uma gratificação.");
                mskdGratificacao.Focus();
            }
        }
    }
}
